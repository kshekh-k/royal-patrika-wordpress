<?php
/**
 * The template for displaying the header
 *
 * This is the template that displays all of the <head> section, opens the <body> tag, and adds the site's header.
 *
 * @package HelloElementor
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

$viewport_content = apply_filters( 'hello_elementor_viewport_content', 'width=device-width, initial-scale=1' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="<?php echo esc_attr( $viewport_content ); ?>">
   <?php $timestamp = time(); ?>
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/bootstrap.min.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/owl.carousel.min.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/fontawsome.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/lightgallery.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/style.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
<link href="<?php echo get_stylesheet_directory_uri(); ?>/assets/css/responsive.css?ver=<?php echo $timestamp; ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
    <?php wp_head(); ?>
<meta name="facebook-domain-verification" content="zjji8irxabaq1ryhv2nqexm7llpsqq" />
     <?php if (is_single()) : ?>
        <meta property="og:title" content="<?php echo esc_attr(get_the_title()); ?>" />
        <meta property="og:description" content="<?php echo esc_attr(get_the_excerpt()); ?>" />
        <meta property="og:url" content="<?php echo esc_url(get_permalink()); ?>" />
        <meta property="og:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
        <meta property="og:type" content="article" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="<?php echo esc_attr(get_the_title()); ?>" />
        <meta name="twitter:description" content="<?php echo esc_attr(get_the_excerpt()); ?>" />
        <meta name="twitter:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" />
    <?php endif; ?>
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5527790384256550"
     crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" ></script>

</head>
<body <?php body_class(); ?>>
<!-- Main Header -->
<header class="header-part pt-2" id="header">
    <div class="container pb-2 header-logo-ads">
        <div class="header-top">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="header-logo">
                        <a alt="Logo" href="<?php echo site_url(); ?>">
                            <img src="/wp-content/uploads/2024/07/Royal-Patrika-PNG.png" height="185" width="195" alt="Royal Patrika Logo" title="Royal Patrika Logo">
                        </a>
                    </div>
                </div>
                <div class="col-md-8">
                    <?php if ( is_active_sidebar( 'google-ads' ) ) : ?>
                        <?php dynamic_sidebar( 'google-ads' ); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar">
        <div class="container">
            <div class="row">
                <div class="col-md-2 header-toggle">
                    <button id="hamburger" class="hamburger" aria-label="Toggle navigation">&#9776;</button>
                    <img src="/wp-content/uploads/2024/06/royal-patrika-logo.png" height="auto" width="105" alt="Royal Patrika Logo" title="Royal Patrika Logo">
                    <div id="sidebar" class="sidebar">
                        <button id="close-btn" class="close-btn" aria-label="Close navigation">&times;</button>
                        <div class="mobile-main-menu">
                            <?php
                            if ( wp_is_mobile() ){
                                wp_nav_menu( array(
                                    'theme_location' => 'primary',
                                    'container'      => 'ul',
                                    'menu_class'     => 'sidebar-menu'
                                ) );
                            }
                            ?>
                            <h2>Categories</h2>
                            <ul>
                                <?php 
                                $categories = get_categories();
                                foreach ( $categories as $category ) {
                                    echo '<li><a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a></li>';
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="royal-main-menu">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'primary',
                            'container'      => 'ul',
                            'menu_class'     => 'header-menu'
                        ) );
                        ?>
                    </div>
                </div>
                <div class="col-md-2 header-time"><div id="real-time-clock"></div></div>
            </div>
        </div>
    </nav>
    <section class="google-ads top">
        <div class="container p-2">
            <?php if (is_active_sidebar('google-ads-top')) : ?>
                <?php dynamic_sidebar('google-ads-top'); ?>
            <?php endif; ?>
        </div>
    </section>
</header>

<!-- Sticky Header -->
<header class="sticky-header" id="sticky-header">
    <nav class="navbar">
        <div class="container">
            <div class="row">
                <div class="col-md-2 header-toggle">
                    <button id="hamburger-sticky" class="hamburger" aria-label="Toggle navigation">&#9776;</button>
                    <img src="/wp-content/uploads/2024/06/royal-patrika-logo.png" height="auto" width="105" alt="Royal Patrika Logo" title="Royal Patrika Logo">
                    <div id="sidebar-sticky" class="sidebar">
                        <button id="close-btn-sticky" class="close-btn" aria-label="Close navigation">&times;</button>
                        <div class="mobile-main-menu">
                            <?php
                            if ( wp_is_mobile() ){
                                wp_nav_menu( array(
                                    'theme_location' => 'primary',
                                    'container'      => 'ul',
                                    'menu_class'     => 'sidebar-menu'
                                ) );
                            }
                            ?>
                            <h2>Categories</h2>
                            <ul>
                                <?php 
                                $categories = get_categories();
                                foreach ( $categories as $category ) {
                                    echo '<li><a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a></li>';
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 ">
                    <div class="royal-main-menu d-sm-none d-md-block">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'primary',
                            'container'      => 'ul',
                            'menu_class'     => 'header-menu'
                        ) );
                        ?>
                    </div>
					  <div class="royal-mobile-menu d-sm-block d-md-none">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'mobile-header',
                            'container'      => 'ul',
                            'menu_class'     => 'mobile-menu-sec'
                        ) );
                        ?>
                    </div>
                </div>
                <div class="col-md-2 header-time"><div id="real-time-clock-sticky"></div></div>
            </div>
        </div>
    </nav>
</header>
