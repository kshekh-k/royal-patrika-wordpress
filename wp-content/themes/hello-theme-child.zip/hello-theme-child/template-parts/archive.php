<?php
get_header();
global $post;
if ( isset( $post ) && !empty( $post ) ) {
    $Page_ID = $post->ID;
} else {
    $Page_ID = null;
}

if (!defined('ABSPATH')) {
    echo "No Script";
    exit;
}
?>

<div class="content-wrapper p-2">
    <aside class="google-ads left" id="google-ads-left">
        <?php if (is_active_sidebar('google-ads-left')) : ?>
            <?php dynamic_sidebar('google-ads-left'); ?>
        <?php endif; ?>
    </aside>
    
    <section class="homenews-page">
        <div class="container">
            <div class="breadcrumb-sec">
                <?php echo do_shortcode('[wpseo_breadcrumb]'); ?>
            </div>
            <div class="post-content row">
                <div class="heading">
                    <h3 class="text-center big-news-title"><?php single_cat_title(); ?></h3>
                </div>
                <div class="col-xs-12 col-md-12 post-content-sec">
                    <?php
                    // Query for Big News Posts
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    $cat_id = get_queried_object_id();
                    $args = array(
                        'posts_per_page' => 4,
                        'post_type' => 'post',
                        'paged' => $paged,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'category',
                                'field' => 'term_id',
                                'terms' => $cat_id,
                            ),
                        ),
                    );
                    $big_news_query = new WP_Query($args);

                    if ($big_news_query->have_posts()) : ?>
                        <div class="big-news-slider">
                            <?php
                            $post_count = 0; // Initialize the post counter
                            while ($big_news_query->have_posts()) : $big_news_query->the_post();
                                $post_count++; // Increment the post counter
                                if ($post_count == 1) : ?>
                                    <div class="col-sm-6 first-big-news-slide">
                                        <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
                                        <div class="news-meta">
                                            <?php $post_id = get_the_ID(); ?>
                                            <?php $post_location = get_field('posts_location', $post_id); ?>				
                                            <ul class="news-postmeta">
                                                <li id="news-location" class="post_location"><span><?php echo $post_location; ?></span></li>
                                                <li id="news-date-time" class="published-date"><span><?php the_time('F jS, Y'); ?> <?php the_time('g:i a'); ?></span></li>
                                            </ul>                   
                                        </div>
                                        <p class="post content"><?php the_excerpt(); ?></p>
                                        <?php if (has_post_thumbnail()) : ?>
                                            <div class="big-news-image">
                                                <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php else :
                                    if ($post_count == 2) : ?>
                                        <div class="col-sm-6 other-big-news-slide">
                                    <?php endif; ?>
                                    <div class="other-big-news-item">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <div class="big-news-image">
                                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                                            </div>
                                        <?php else : ?>
                                            <div class="big-news-image">
                                                <a href="<?php echo esc_url(get_permalink()); ?>" class="news-image-link">
                                                    <img class="attachment-post-thumbnail size-post-thumbnail wp-post-image" src="https://royalpatrika.com/wp-content/uploads/2024/07/no-image.png" alt="<?php the_title(); ?>" />
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="big-news-other-content">
                                            <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="post-id-<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
                                            <div class="news-meta">
                                                <?php $post_id = get_the_ID(); ?>
                                                <?php $post_location = get_field('posts_location', $post_id); ?>
                                                <ul class="news-postmeta">
                                                    <li id="news-location" class="post_location"><span><?php echo $post_location; ?></span></li>
                                                    <li id="news-date-time" class="published-date"><span><?php the_time('F jS, Y'); ?> <?php the_time('g:i a'); ?></span></li>
                                                </ul>
                                            </div>
                                            <p class="post content"><?php echo get_the_excerpt(); ?></p>
                                        </div>
                                    </div>
                                    <?php
                                    // For the last post, close the container div
                                    if ($post_count == $big_news_query->post_count) : ?>
                                        </div>
                                    <?php endif;
                                endif;
                            endwhile;
                            wp_reset_postdata(); ?>
                        </div>
                        <div class="pagination">
                            <?php
                            echo paginate_links(array(
                                'total' => $big_news_query->max_num_pages,
                                'current' => $paged,
                                'prev_text' => __('Prev'),
                                'next_text' => __('Next'),
                            ));
                            ?>
                        </div>
                    <?php else : ?>
                        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <aside class="google-ads right" id="google-ads-right">
        <?php if (is_active_sidebar('google-ads-right')) : ?>
            <?php dynamic_sidebar('google-ads-right'); ?>
        <?php endif; ?>
    </aside>
</div>

<?php get_footer(); ?>
