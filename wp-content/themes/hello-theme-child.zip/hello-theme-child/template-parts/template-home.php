<?php
/*
Template Name: Home
*/
get_header();
global $post;
$Page_ID = $post->ID;
?>
<?php if (!defined("ABSPATH")) {
    echo "No Script";
    exit();
} ?>
<?php get_header(); ?>

<div class="content-wrapper p-2">
    <aside class="google-ads left" id="google-ads-left">
        <?php if (is_active_sidebar("google-ads-left")): ?>
            <?php dynamic_sidebar("google-ads-left"); ?>
        <?php endif; ?>
    </aside>
    
<section class="homenews-page">
        <div class="container latest-big-news-sec">
            <div class="post-content row">
                        <div class="heading ">
                        <h3 class="text-center big-news-title">आज के बड़े घटनाक्रम</h3>
            </div>
                <div class="col-xs-12 col-md-12 post-content-sec ">
                        
                
            <?php // Query for Big News Posts


            $cat_id = 11;
            $args = [
                "posts_per_page" => 4,
                "post_type" => "post",
                "tax_query" => [
                    [
                        "taxonomy" => "category",
                        "field" => "id",
                        "terms" => $cat_id,
                    ],
                ],
                "orderby" => "date",
                "order" => "DESC",
            ];
            $big_news_query = new WP_Query($args);
            if ($big_news_query->have_posts()): ?>
 
        <div class="big-news-slider">
            <?php
            $post_count = 0; // Initialize the post counter
            while ($big_news_query->have_posts()):
                $big_news_query->the_post();
                $post_count++; // Increment the post counter
                if ($post_count == 1): ?>
                    <div class="col-sm-6 first-big-news-slide">
                        <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
					<div class="news-meta">
							<?php $post_id = get_the_ID(); ?>
		<?php $post_location = get_field("posts_location", $post_id); ?>				
                         <ul class="news-postmeta">
           <li id="news-location" class="post_location"><span ><?php echo $post_location; ?></span></li>
                           
                            <li id="news-date-time" class="published-date"><span><?php the_time(
                                "F jS, Y"
                            ); ?> <?php the_time("g:i a"); ?></span></li>
<!--                               <li id="news-author" class="author"><span><?php
                    //the_author_posts_link()
                    ?> </span></li> -->

                         </ul>                   
                    </div>
                        <div class="post content"><?php the_excerpt(); ?></div>
                   <div class="big-news-image">
					   <a href="<?php the_permalink(); ?>">
						   <?php if (has_post_thumbnail()): ?>
						   <?php if (wp_is_mobile()) {
             // Display a smaller thumbnail size for mobile devices
             the_post_thumbnail("full");
             // Replace 'thumbnail' with your desired size for mobile
         } else {
             the_post_thumbnail();
             // Default size for non-mobile devices
         } ?>
						   <?php else: ?>
						   <img src="https://royalpatrika.com/wp-content/uploads/2024/07/no-image.png" alt="<?php the_title(); ?>" />
						   <?php endif; ?>
					   </a>
				</div>

                    </div>
                <?php
                    // Display a smaller thumbnail size for mobile devices
                    // Replace 'thumbnail' with your desired size for mobile // Default size for non-mobile devices

                    //the_author_posts_link()
                    // For the last post, close the container div

                    else:if ($post_count == 2): ?>
                        <div class="col-sm-6 other-big-news-slide">
                    <?php endif; ?>
                        <div class="other-big-news-item">
                            <div class="big-news-image">
								<a href="<?php the_permalink(); ?>">
									<?php if (has_post_thumbnail()): ?>
										<?php if (wp_is_mobile()) {
              the_post_thumbnail("full");
          } else {
              the_post_thumbnail();
          } ?>
									<?php else: ?>
										<img src="https://royalpatrika.com/wp-content/uploads/2024/07/no-image.png" alt="<?php the_title(); ?>" />
									<?php endif; ?>
								</a>
							</div>

                            <div class="big-news-other-content">
                                <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="post-id-<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
					<div class="news-meta">
							<?php $post_id = get_the_ID(); ?>
		<?php $post_location = get_field("posts_location", $post_id); ?>				
                         <ul class="news-postmeta">
           <li id="news-location" class="post_location"><span ><?php echo $post_location; ?></span></li>
                           
                            <li id="news-date-time" class="published-date"><span><?php the_time(
                                "F jS, Y"
                            ); ?> <?php the_time("g:i a"); ?></span></li>
<!--                               <li id="news-author" class="author"><span><?php
                    //the_author_posts_link()
                    ?> </span></li> -->

                         </ul>                   
                    </div>
                                <div class="post content"><?php the_excerpt(); ?></div>
                            </div>
                        </div>
                    <?php if ($post_count == $big_news_query->post_count): ?>
                        </div>
                    <?php endif;endif;
            endwhile;
            wp_reset_postdata();
            ?>
        </div>
    <?php endif;
            ?>

            </div>
            </div>
        </div>
<div class="container home-category-sec">
        <div class="post-content row">
            <?php
            // Retrieve categories excluding those with IDs 11 and 1
            $category_args = [
                "hide_empty" => 0,
                "type" => "post",
                "order" => "ASC",
                "include" => [30, 6, 27, 31, 28, 29],

                // Exclude categories with IDs 11 and 1
            ];

            $category_lists = get_categories($category_args); // Loop through each category and display posts if the category has posts
            if (!empty($category_lists)) {
                foreach ($category_lists as $category) {
                    $category_id = $category->term_id;
                    $category_name = $category->name; // Query for Big News Posts
                    $args = [
                        "posts_per_page" => 4,
                        "post_type" => "post",
                        "tax_query" => [
                            [
                                "taxonomy" => "category",
                                "field" => "id",
                                "terms" => $category_id,
                            ],
                        ],
                    ];
                    $big_news_query = new WP_Query($args); // Check if the category has posts
                    if ($big_news_query->have_posts()): ?>
			<div class="post-category-artical">
                        <div class="heading">
                            <h3 class="text-center big-news-title"><?php echo esc_html(
                                $category_name
                            ); ?></h3>
                        </div>
                        <div class="col-xs-12 col-md-12 post-content-sec">
                            <div class="big-news-slider">
                                <?php
                                $post_count = 0;
                                // Initialize the post counter
                                while ($big_news_query->have_posts()):
                                    $big_news_query->the_post();
                                    $post_count++;
                                    // Increment the post counter
                                    if ($post_count == 1): ?>
                                        <div class="col-sm-6 first-big-news-slide">
                                            <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
																<div class="news-meta">
							<?php $post_id = get_the_ID(); ?>
		<?php $post_location = get_field("posts_location", $post_id); ?>				
                         <ul class="news-postmeta">
           <li id="news-location" class="post_location"><span ><?php echo $post_location; ?></span></li>
                           
                            <li id="news-date-time" class="published-date"><span><?php the_time(
                                "F jS, Y"
                            ); ?> <?php the_time("g:i a"); ?></span></li>
<!--                               <li id="news-author" class="author"><span><?php
                                        //the_author_posts_link()
                                        ?> </span></li> -->

                         </ul>                   
                    </div>
                                            <div class="post content"><?php the_excerpt(); ?></div>
                                            <?php if (has_post_thumbnail()): ?>
                                                <div class="big-news-image">
                                                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php

                                        //the_author_posts_link()
                                        // For the last post, close the container div

                                        else:if ($post_count == 2): ?>
                                            <div class="col-sm-6 other-big-news-slide">
                                        <?php endif; ?>
                                        <div class="other-big-news-item">
                                            <?php if (has_post_thumbnail()): ?>
                                                <div class="big-news-image">
                                                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                                                </div>
                                            <?php endif; ?>
                                            <div class="big-news-other-content">
                                                <a href="<?php the_permalink(); ?>"><h2 class="post-title" id="post-id-<?php the_ID(); ?>"><?php the_title(); ?></h2></a>
																	<div class="news-meta">
							<?php $post_id = get_the_ID(); ?>
		<?php $post_location = get_field("posts_location", $post_id); ?>				
                         <ul class="news-postmeta">
           <li id="news-location" class="post_location"><span ><?php echo $post_location; ?></span></li>
                           
                            <li id="news-date-time" class="published-date"><span><?php the_time(
                                "F jS, Y"
                            ); ?> <?php the_time("g:i a"); ?></span></li>
<!--                               <li id="news-author" class="author"><span><?php
                                        //the_author_posts_link()
                                        ?> </span></li> -->

                         </ul>                   
                    </div>
                                                <div class="post content"><?php the_excerpt(); ?></div>
                                            </div>
                                        </div>
                                        <?php if (
                                            $post_count ==
                                            $big_news_query->post_count
                                        ): ?>
                                            </div>
                                        <?php endif;endif;
                                endwhile;
                                wp_reset_postdata();
                                ?>
                            </div>
                        </div>
								
			</div>
                    <?php endif;
                }
            }
            ?>
        </div>
    </div>
	

</section>

    <aside class="google-ads right" id="google-ads-right" >
        <?php if (is_active_sidebar("google-ads-right")): ?>
            <?php dynamic_sidebar("google-ads-right"); ?>
        <?php endif; ?>
    </aside>
</div>

<section id="youtube-channel">
	<div class="container">
    <h2 class="youtube_heading ">ट्रेंडिंग वीडियो</h2>
    <div class="video-container">
		<?php echo do_shortcode("[youtube-feed feed=1]"); ?>
    </div>
	</div>	
</section>


<?php get_footer(); ?>
