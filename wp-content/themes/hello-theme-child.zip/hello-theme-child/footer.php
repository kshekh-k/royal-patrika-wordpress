<?php if(!defined('ABSPATH')){ echo "No Script"; exit; }
global $wstheme_options,$theme_dir;
?>



<footer>
    <div class="container">
        <div class="row ">
          <div class="col-md-6">
            <div class="footer-logo">
              <a alt="Logo" href="<?php echo site_url(); ?>">
                <img src="/wp-content/uploads/2024/06/royal-patrika-logo.png" heght="185" width="195" alt="Royal patrika Logo" title="Royal patrika Logo">        
              </a>
              
            </div>
            <div class="footer-heading">
                <p>रॉयल पत्रिका न्यूज़पेपर को पाठकों द्वारा काफी पसंद दिया जा रहा है ,क्योंकि रॉयल पत्रिका लीक से हटकर कुछ करने की कोशिश कर रहा है। रॉयल पत्रिका आज की आर्थिक भाग दौड़ में भी आम समस्याओं , घटनाओं, शिक्षा एवं सामाजिक बदलाव की खबरों को प्राथमिकता देता है। अपने पाठकों के भरोसे पर खरा उतरने, प्रदेश व देश के प्रति अपनी जिम्मेदारी को समझते हुए रॉयल पत्रिका खबरों को प्रकाशित करता है। रॉयल पत्रिका देश व समाज में आपसी भाईचारा, शांति एवं सद्भाव बनाए रखने के लिए मिशन की तरह काम करता है।</p>
            </div>
        </div>
          <div class="col-md-3">
              <div class="royal-footer-menu ">
                <h3>Explore More</h3>
                  <?php
                  wp_nav_menu( array(
                        'theme_location' => 'footer-menu-link',
                        'container' => 'ul',
                        'sub_menu' => true,
                        'menu_class'=> 'footer-menu'
                     ) );
                   ?>
                 </div>
          </div>
          <div class="col-md-3 footer-newslatter" >
            <h3>Newsletter</h3>
            <p>Heaven fruitful doesn't over les idays appear creeping</p>
            <?php echo do_shortcode('[newsletter_form]');?>
          <div class="social-share">
            <a href="https://www.facebook.com/royalpatrika/" class="fa fa-facebook"></a>
            <a href="https://x.com/PatrikaRoyal" class="fa fa-twitter"></a>
            <a href="https://www.youtube.com/@royalpatrika" class="fa fa-youtube"></a>
            <a href="https://www.instagram.com/patrikaroyal/" class="fa fa-instagram"></a>
          </div>
          </div>
        </div>

     <div class="footer-inner-inner"><p>Copyright ©<?php echo date('Y');?> All rights reserved  by <a href="<?php echo site_url(); ?>">Royal Patrika</a></p>
      </div>
    </div>
    
    
    
    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body modal-poup-contactform">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-close"></i></button>
            <?php echo do_shortcode('[contact-form-7 id="acae1c1" title="Contact form 1"]');?>
          </div>
        </div>
      </div>
    </div>
    
    
  </footer>
  <!-- Scroll to top -->
  <div class="scroll-to-top">
    <a href="#!" onclick="scrollToTop()"><i class="fa-solid fa-chevron-up"></i></a>
  </div>
  <!-- Scroll to top -->
<?php $timestamp = time(); ?>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/jquery.min.js?ver=<?php echo $timestamp; ?>"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/owl.carousel.min.js?ver=<?php echo $timestamp; ?>"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/lightgallery.js?ver=<?php echo $timestamp; ?>"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/bootstrap.bundle.min.js?ver=<?php echo $timestamp; ?>"></script>
  <script src="<?php echo get_stylesheet_directory_uri(); ?>/assets/js/custom.js?ver=<?php echo $timestamp; ?>"></script>
<script>
  jQuery(document).ready(function($) {
    $("#custom-prev").on("click", function() {
      fpvPrevPage(); // Call existing function
    });

    $("#custom-next").on("click", function() {
      fpvNextPage(); // Call existing function
    });
  });
</script>
<script>
jQuery(document).ready(function($) {
    $('.header-menu').addClass('owl-carousel').owlCarousel({
        items: 5,
        margin: 10,
        nav: true,
        dots: false,
        autoplay: false,
        autoWidth: true, // allows dynamic width
        responsive: {
            0: { items: 2 },
            600: { items: 4 },
            1000: { items: 6 }
        }
    });
});

</script>

 <?php wp_footer(); ?>
</body>

</html>




    
