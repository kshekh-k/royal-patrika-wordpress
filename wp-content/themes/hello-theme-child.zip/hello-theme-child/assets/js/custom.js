jQuery(document).ready(function ($) {
    // Sticky header
    $(window).scroll(function () {
        // Scroll to top
        var scrollTopSticky = $(".scroll-to-top");
        scrollTop = $(window).scrollTop();

        if (scrollTop >= 500) scrollTopSticky.addClass("sticky-visible");
        else scrollTopSticky.removeClass("sticky-visible");
        // Scroll to top
    });
});

// Scroll to top
function scrollToTop() {
    window.scrollTo(0, 0);
}
// Scroll to top