<?php
/**
 * Theme functions and definitions.
 *
 * For additional information on potential customization options,
 * read the developers' documentation:
 *
 * https://developers.elementor.com/docs/hello-elementor-theme/
 *
 * @package HelloElementorChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'HELLO_ELEMENTOR_CHILD_VERSION', '2.0.0' );

/**
 * Load child theme scripts & styles.
 *
 * @return void
 */
function hello_elementor_child_scripts_styles() {

	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[
			'hello-elementor-theme-style',
		],
		time()
	);

}
add_action( 'wp_enqueue_scripts', 'hello_elementor_child_scripts_styles', 20 );

// custom js 
function enqueue_custom_scripts() {
    wp_enqueue_script('custom-scripts', get_stylesheet_directory_uri() . '/assets/custom/custom-script.js', array('jquery'), time(), true);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');


//menu register
function news_channel_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'news-channel-theme'),
        'footer-menu-link' => __('Footer Menu', 'news-channel-theme'),
		'mobile-header' => __('Mobile Menu', 'news-channel-theme')
    ));
}
add_action('after_setup_theme', 'news_channel_theme_setup');

add_action( 'wp_footer', 'check_mobile_function' );

function check_mobile_function() {
    if ( wp_is_mobile() ) {
        echo '<!-- wp_is_mobile: true -->';
    } else {
        echo '<!-- wp_is_mobile: false -->';
    }
}
// Google Ads widgets
function news_header_ads_widgets() {
    register_sidebar(array(
        'name'          => __('Google Ads Header', 'news-channel-theme'),
        'id'            => 'google-ads',
        'before_widget' => '<div class="widget google-ads">',
        'after_widget'  => '</div>',
    ));

        register_sidebar(array(
        'name' => 'Google Ads Top',
        'id' => 'google-ads-top',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => 'Google Ads Left',
        'id' => 'google-ads-left',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));
    register_sidebar(array(
        'name' => 'Google Ads Right',
        'id' => 'google-ads-right',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));
	
	    register_sidebar(array(
        'name' => 'Post detail page ads1',
        'id' => 'post_detail_page_ads1',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));
		register_sidebar(array(
        'name' => 'Post detail page ads2',
        'id' => 'post_detail_page_ads2',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="widgettitle">',
        'after_title' => '</h2>',
    ));
		register_sidebar(array(
        'name' => '404 page News',
        'id' => '404_page_news',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="trading_newstitle">',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'news_header_ads_widgets');

function new_excerpt_more($more) {
    global $post;
	$post_id = $post->ID;
    return '... <a class="reveal-full-content"  action-id ="' . $post->ID .'" href="'.get_permalink($post_id).'">Read more</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

// e-paper custom post type
function royalpatrika_epaper_cpt() {
    $labels = array(
        'name' => _x('E-Papers', 'Post Type General Name', 'royalpatrika'),
        'singular_name' => _x('E-Paper', 'Post Type Singular Name', 'royalpatrika'),
        'menu_name' => __('E-Papers', 'royalpatrika'),
        'name_admin_bar' => __('E-Paper', 'royalpatrika'),
        'archives' => __('E-Paper Archives', 'royalpatrika'),
        'attributes' => __('E-Paper Attributes', 'royalpatrika'),
        'parent_item_colon' => __('Parent E-Paper:', 'royalpatrika'),
        'all_items' => __('All E-Papers', 'royalpatrika'),
        'add_new_item' => __('Add New E-Paper', 'royalpatrika'),
        'add_new' => __('Add New', 'royalpatrika'),
        'new_item' => __('New E-Paper', 'royalpatrika'),
        'edit_item' => __('Edit E-Paper', 'royalpatrika'),
        'update_item' => __('Update E-Paper', 'royalpatrika'),
        'view_item' => __('View E-Paper', 'royalpatrika'),
        'view_items' => __('View E-Papers', 'royalpatrika'),
        'search_items' => __('Search E-Paper', 'royalpatrika'),
        'not_found' => __('Not found', 'royalpatrika'),
        'not_found_in_trash' => __('Not found in Trash', 'royalpatrika'),
        'featured_image' => __('Featured Image', 'royalpatrika'),
        'set_featured_image' => __('Set featured image', 'royalpatrika'),
        'remove_featured_image' => __('Remove featured image', 'royalpatrika'),
        'use_featured_image' => __('Use as featured image', 'royalpatrika'),
        'insert_into_item' => __('Insert into E-Paper', 'royalpatrika'),
        'uploaded_to_this_item' => __('Uploaded to this E-Paper', 'royalpatrika'),
        'items_list' => __('E-Papers list', 'royalpatrika'),
        'items_list_navigation' => __('E-Papers list navigation', 'royalpatrika'),
        'filter_items_list' => __('Filter E-Papers list', 'royalpatrika'),
    );
    $args = array(
        'label' => __('E-Paper', 'royalpatrika'),
        'description' => __('E-Paper custom post type', 'royalpatrika'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
        'taxonomies' => array('epaper_category'), // This will be the custom taxonomy
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('epaper', $args);
}
add_action('init', 'royalpatrika_epaper_cpt', 0);

function create_epaper_taxonomy() {
    $labels = array(
        'name' => _x('E-Paper Categories', 'Taxonomy General Name', 'royalpatrika'),
        'singular_name' => _x('E-Paper Category', 'Taxonomy Singular Name', 'royalpatrika'),
        'menu_name' => __('E-Paper Categories', 'royalpatrika'),
        'all_items' => __('All Categories', 'royalpatrika'),
        'parent_item' => __('Parent Category', 'royalpatrika'),
        'parent_item_colon' => __('Parent Category:', 'royalpatrika'),
        'new_item_name' => __('New Category Name', 'royalpatrika'),
        'add_new_item' => __('Add New Category', 'royalpatrika'),
        'edit_item' => __('Edit Category', 'royalpatrika'),
        'update_item' => __('Update Category', 'royalpatrika'),
        'view_item' => __('View Category', 'royalpatrika'),
        'separate_items_with_commas' => __('Separate categories with commas', 'royalpatrika'),
        'add_or_remove_items' => __('Add or remove categories', 'royalpatrika'),
        'choose_from_most_used' => __('Choose from the most used', 'royalpatrika'),
        'popular_items' => __('Popular Categories', 'royalpatrika'),
        'search_items' => __('Search Categories', 'royalpatrika'),
        'not_found' => __('Not Found', 'royalpatrika'),
        'no_terms' => __('No categories', 'royalpatrika'),
        'items_list' => __('Categories list', 'royalpatrika'),
        'items_list_navigation' => __('Categories list navigation', 'royalpatrika'),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'public' => true,
        'show_ui' => true,
        'show_admin_column' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
    );
    register_taxonomy('epaper_category', array('epaper'), $args);
}
add_action('init', 'create_epaper_taxonomy', 0);

//custom excerpt length
function custom_excerpt_length($length) {
    return 20; // Change this to the number of words you want
}
add_filter('excerpt_length', 'custom_excerpt_length', 999);

// customurl
function createFriendlyURL($url) {
    // Parse the URL to get the components
    $parsedUrl = parse_url($url);
    $path = $parsedUrl['path'];
    
    // URL-decode the path
    $decodedPath = urldecode($path);
    
    // Construct the friendly URL
    $friendlyUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'] . $decodedPath;
    
    return $friendlyUrl;
}

function hindi_to_english_slug($title) {
    $hindi = array(
        'अ', 'आ', 'इ', 'ई', 'उ', 'ऊ', 'ए', 'ऐ', 'ओ', 'औ', 'क', 'ख', 'ग', 'घ', 'च', 'छ', 'ज', 'झ', 'ट', 'ठ', 'ड', 'ढ', 'त', 'थ', 'द', 'ध', 'न', 'प', 'फ', 'ब', 'भ', 'म', 'य', 'र', 'ल', 'व', 'श', 'ष', 'स', 'ह',
        'ा', 'ि', 'ी', 'ु', 'ू', 'े', 'ै', 'ो', 'ौ', 'ं', 'ः', '्'
    );

    $english = array(
        'a', 'aa', 'i', 'ii', 'u', 'uu', 'e', 'ai', 'o', 'au', 'k', 'kh', 'g', 'gh', 'ch', 'chh', 'j', 'jh', 't', 'th', 'd', 'dh', 't', 'th', 'd', 'dh', 'n', 'p', 'ph', 'b', 'bh', 'm', 'y', 'r', 'l', 'v', 'sh', 'shh', 's', 'h',
        'a', 'i', 'ii', 'u', 'uu', 'e', 'ai', 'o', 'au', 'an', 'ah', ''
    );

    $title = str_replace($hindi, $english, $title);
    return $title;
}
add_filter('sanitize_title', 'hindi_to_english_slug', 10);

